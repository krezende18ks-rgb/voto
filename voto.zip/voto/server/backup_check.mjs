import { beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createRequire } from 'node:module';
import crypto from 'node:crypto';

process.env.AUTH_SECRET = 'test-secret-key-that-is-long-enough-for-unit-tests-123456';
process.env.DATABASE_URL = 'postgresql://unused:unused@127.0.0.1:1/classvote_test';

const require = createRequire(import.meta.url);
const Module = require('node:module');

const SECRET = process.env.AUTH_SECRET;

const users = {
  '1': { id: 1, email: 'aluno@teste.com', name: 'Aluno Teste', matric: 'MAT-ALUNO-001', role: 'voter', class: 'A', course: 'Engenharia' },
  '2': { id: 2, email: 'professor@teste.com', name: 'Professor Teste', matric: null, role: 'teacher', class: null, course: 'Engenharia' },
  '3': { id: 3, email: 'coordenador@teste.com', name: 'Coordenador Teste', matric: null, role: 'coordinator', class: null, course: 'Engenharia' },
  '4': { id: 4, email: 'reitor@teste.com', name: 'Reitor Teste', matric: null, role: 'rector', class: null, course: null },
  '5': { id: 5, email: 'aluno2@teste.com', name: 'Aluno Computação', matric: 'MAT-ALUNO-005', role: 'voter', class: 'B', course: 'Computação' },
  '6': { id: 6, email: 'coordenador2@teste.com', name: 'Segundo Coordenador', matric: null, role: 'coordinator', class: null, course: 'Engenharia' },
};

const state = {
  queries: [],
  validTurma: true,
  duplicate: false,
  elections: [],
  insertedElection: null,
  candidateDuplicate: false,
  candidates: [],
  ballots: [],
  participation: [],
  electionBlockchain: [],
  failBlockchainInsert: false,
};

const mockDb = {
  query: async (sql, params = []) => {
    state.queries.push({ sql, params });

    if (/DELETE FROM users/i.test(sql)) {
      const [email, courseScope] = params;
      const target = Object.values(users).find(user =>
        user.email.toLowerCase() === String(email).toLowerCase()
      );

      const roleRestricted = /role\s+IN\s*\(\s*'voter'\s*,\s*'teacher'\s*\)/i.test(sql);

      const allowed = target && (
        courseScope === null ||
        (
          target.course === courseScope &&
          roleRestricted &&
          ['voter', 'teacher'].includes(target.role)
        )
      );

      return { rows: [], rowCount: allowed ? 1 : 0 };
    }
    if (/SELECT id,role,class,course FROM users WHERE id=\$1 LIMIT 1/i.test(sql)) {
      const user = users[String(params[0])];
      return { rows: user ? [user] : [], rowCount: user ? 1 : 0 };
    }

    if (/SELECT 1 FROM turmas WHERE name = \$1 AND course = \$2/i.test(sql)) {
      const rows = state.validTurma ? [{ '?column?': 1 }] : [];
      return { rows, rowCount: rows.length };
    }

    if (/INSERT INTO candidates/i.test(sql)) {
      const [id, name, matric, phone, email, candidateClass, course, position] = params;

      const candidate = {
        id,
        name,
        matric,
        phone,
        email,
        class: candidateClass,
        course,
        position,
      };

      state.candidates.push(candidate);
      return { rows: [candidate], rowCount: 1 };
    }

    if (/INSERT INTO elections/i.test(sql)) {
      if (state.duplicate) {
        const error = new Error('duplicate key');
        error.code = '23505';
        throw error;
      }

      return {
        rows: state.insertedElection ? [state.insertedElection] : [],
        rowCount: 1,
      };
    }

    if (/INSERT INTO election_candidates/i.test(sql)) {
      const [
        electionId,
        courseScope,
        candidateId,
        name,
        matric,
        phone,
        email,
        position
      ] = params;

      const election = state.elections.find(row =>
        row.id === electionId &&
        row.status === 'draft' &&
        (!courseScope || row.course === courseScope)
      );

      if (!election) {
        return { rows: [], rowCount: 0 };
      }

      if (
        state.candidateDuplicate ||
        state.candidates.some(row =>
          row.election_id === electionId && row.matric === matric
        )
      ) {
        const error = new Error('duplicate key');
        error.code = '23505';
        throw error;
      }

      const candidate = {
        id: candidateId,
        electionId,
        election_id: electionId,
        name,
        matric,
        phone,
        email,
        position,
      };

      state.candidates.push(candidate);

      return { rows: [candidate], rowCount: 1 };
    }

    if (/FROM election_candidates/i.test(sql)) {
      const electionId = params[0];
      const rows = state.candidates
        .filter(row => row.election_id === electionId)
        .map(row => {
          if (/SELECT id, name, position/i.test(sql)) {
            return {
              id: row.id,
              name: row.name,
              position: row.position,
            };
          }

          return {
            id: row.id,
            name: row.name,
            matric: row.matric,
            phone: row.phone,
            email: row.email,
            position: row.position,
          };
        });

      return { rows, rowCount: rows.length };
    }
    if (/UPDATE elections/i.test(sql)) {
      const [electionId, courseScope] = params;
      const election = state.elections.find(row =>
        row.id === electionId &&
        (!courseScope || row.course === courseScope)
      );

      const starting = /SET status = 'open'/i.test(sql);
      const ending = /SET status = 'closed'/i.test(sql);
      const expectedStatus = starting ? 'draft' : 'open';

      if (!election || election.status !== expectedStatus) {
        return { rows: [], rowCount: 0 };
      }

      if (starting) {
        const conflict = state.elections.some(row =>
          row.id !== election.id &&
          row.class === election.class &&
          row.course === election.course &&
          row.status === 'open'
        );

        if (conflict) {
          const error = new Error('duplicate key');
          error.code = '23505';
          throw error;
        }

        election.status = 'open';
        election.startedAt = election.startedAt || '2026-11-22T12:00:00.000Z';
      } else if (ending) {
        election.status = 'closed';
        election.endedAt = election.endedAt || '2026-11-22T13:00:00.000Z';
      } else {
        throw new Error('UPDATE elections não reconhecido pelo mock.');
      }

      return {
        rows: [{
          ...election,
          createdBy: election.createdBy ?? 3,
          createdAt: election.createdAt ?? null,
        }],
        rowCount: 1,
      };
    }
    if (/FROM elections/i.test(sql)) {
      let rows = [...state.elections];

      if (/WHERE id = \$1/i.test(sql)) {
        rows = rows.filter(row => row.id === params[0]);

        if (/class = \$2/i.test(sql)) {
          rows = rows.filter(row => row.class === params[1]);
        }

        if (/course = \$3/i.test(sql)) {
          rows = rows.filter(row => row.course === params[2]);
        } else if (/course = \$2/i.test(sql)) {
          rows = rows.filter(row => row.course === params[1]);
        }
      } else if (/class = \$1/i.test(sql) && /course = \$2/i.test(sql)) {
        rows = rows.filter(row =>
          row.class === params[0] && row.course === params[1]
        );
      } else if (/course = \$1/i.test(sql)) {
        rows = rows.filter(row => row.course === params[0]);
      }

      if (/status = 'open'/i.test(sql)) {
        rows = rows.filter(row => row.status === 'open');
      }

      return { rows, rowCount: rows.length };
    }

    throw new Error(`Consulta não prevista no mock: ${sql}`);
  },

  connect: async () => {
    let snapshot = null;

    return {
      query: async (sql, params = []) => {
        if (/^\s*BEGIN\s*$/i.test(sql)) {
          snapshot = {
            elections: structuredClone(state.elections),
            candidates: structuredClone(state.candidates),
            ballots: structuredClone(state.ballots),
            participation: structuredClone(state.participation),
            electionBlockchain: structuredClone(state.electionBlockchain),
          };
          return { rows: [], rowCount: null };
        }

        if (/^\s*COMMIT\s*$/i.test(sql)) {
          snapshot = null;
          return { rows: [], rowCount: null };
        }

        if (/^\s*ROLLBACK\s*$/i.test(sql)) {
          if (snapshot) {
            state.elections = snapshot.elections;
            state.candidates = snapshot.candidates;
            state.ballots = snapshot.ballots;
            state.participation = snapshot.participation;
            state.electionBlockchain = snapshot.electionBlockchain;
            snapshot = null;
          }
          return { rows: [], rowCount: null };
        }

        return mockDb.query(sql, params);
      },
      release: () => {},
    };
  },

  end: async () => {},
};

const dbPath = require.resolve('./db.js');
const mockModule = new Module(dbPath);
mockModule.filename = dbPath;
mockModule.loaded = true;
mockModule.exports = mockDb;
require.cache[dbPath] = mockModule;

const app = require('./index.js');

function tokenFor(userId) {
  const body = Buffer.from(JSON.stringify({
    sub: String(userId),
    exp: Math.floor(Date.now() / 1000) + 3600,
  })).toString('base64url');

  const signature = crypto
    .createHmac('sha256', SECRET)
    .update(body)
    .digest('base64url');

  return `${body}.${signature}`;
}

function auth(userId) {
  return { Authorization: `Bearer ${tokenFor(userId)}` };
}

beforeEach(() => {
  state.queries = [];
  state.ballots = [];
  state.participation = [];
  state.electionBlockchain = [];
  state.validTurma = true;
  state.duplicate = false;
  state.elections = [
    {
      id: 'election_test_1',
      class: 'A',
      course: 'Engenharia',
      period: '2026.2',
      status: 'open',
    },
  ];

  state.candidateDuplicate = false;
  state.candidates = [
    {
      id: 'candidate_test_1',
      election_id: 'election_test_1',
      name: 'Candidato de Teste',
      matric: 'MAT-001',
      phone: '91999999999',
      email: 'candidato@example.com',
      position: 'leader',
    },
    {
      id: 'candidate_test_vice',
      election_id: 'election_test_1',
      name: 'Candidato a Vice',
      matric: 'MAT-002',
      phone: '91988887777',
      email: 'vice@example.com',
      position: 'viceLeader',
    },
  ];

  state.elections.push({
    id: 'election_test_draft',
    class: 'A',
    course: 'Engenharia',
    period: '2027.1',
    status: 'draft',
  });
  state.elections.push({
    id: 'election_test_other_course',
    class: 'B',
    course: 'Computação',
    period: '2027.1',
    status: 'draft',
  });
  state.elections.push({
    id: 'election_test_class_b',
    class: 'B',
    course: 'Engenharia',
    period: '2027.1',
    status: 'draft',
  });
  state.insertedElection = {
    id: 'election_test_new',
    class: 'A',
    course: 'Engenharia',
    period: '2026.2',
    status: 'draft',
    createdBy: 4,
  };
});

describe('API ClassVote - segurança básica', () => {
  it('expõe health check sem autenticação', async () => {
    const response = await request(app).get('/health');
    expect(response.status).toBe(200);
    expect(response.body.status).toBe('ok');
  });

  it('não confia em x-user-role enviado pelo navegador', async () => {
    const response = await request(app)
      .get('/users')
      .set('x-user-role', 'rector');

    expect(response.status).toBe(401);
  });

  it('bloqueia leitura de votos sem token', async () => {
    const response = await request(app).get('/votes');
    expect(response.status).toBe(401);
  });

  it('valida campos obrigatórios do login antes de consultar o banco', async () => {
    const response = await request(app)
      .post('/login')
      .send({ email: '', password: '' });

    expect(response.status).toBe(400);
  });
});

describe('API ClassVote - cadastro legado de candidatos', () => {
  const candidato = {
    id: 'cand_teste_100',
    name: 'Candidato Professor',
    matric: 'MAT-100',
    phone: '91999999999',
    email: 'candidato@teste.com',
    class: 'A',
    course: 'Engenharia',
    position: 'leader',
  };

  it('permite ao professor cadastrar candidato no próprio curso', async () => {
    const response = await request(app)
      .post('/candidates')
      .set(auth(2))
      .send(candidato);

    expect(response.status).toBe(201);
    expect(response.body.id).toBe(candidato.id);

    const insert = state.queries.find(item =>
      /INSERT INTO candidates/i.test(item.sql)
    );

    expect(insert).toBeDefined();
    expect(insert.params[6]).toBe('Engenharia');
  });

  it('impede professor de cadastrar candidato em outro curso', async () => {
    const response = await request(app)
      .post('/candidates')
      .set(auth(2))
      .send({ ...candidato, course: 'Computação', class: 'B' });

    expect(response.status).toBe(403);
    expect(state.queries.some(item =>
      /INSERT INTO candidates/i.test(item.sql)
    )).toBe(false);
  });

  it('permite ao coordenador cadastrar candidato no próprio curso', async () => {
    const response = await request(app)
      .post('/candidates')
      .set(auth(3))
      .send({ ...candidato, id: 'cand_coord_100' });

    expect(response.status).toBe(201);
  });

  it('permite ao reitor cadastrar candidato em outro curso', async () => {
    const response = await request(app)
      .post('/candidates')
      .set(auth(4))
      .send({
        ...candidato,
        id: 'cand_reitor_100',
        course: 'Computação',
        class: 'B',
      });

    expect(response.status).toBe(201);
  });

  it('rejeita turma que não pertence ao curso informado', async () => {
    state.validTurma = false;

    const response = await request(app)
      .post('/candidates')
      .set(auth(2))
      .send({ ...candidato, id: 'cand_turma_invalida' });

    expect(response.status).toBe(400);
    expect(state.queries.some(item =>
      /INSERT INTO candidates/i.test(item.sql)
    )).toBe(false);
  });
});

describe('API ClassVote - candidatos por eleição', () => {
  it('permite ao aluno consultar candidatos da própria eleição aberta', async () => {
    const response = await request(app)
      .get('/elections/election_test_1/candidates')
      .set(auth(1));

    expect(response.status).toBe(200);
    expect(response.body).toHaveLength(1);
        expect(response.status).toBe(200);
    expect(response.body).toHaveLength(2);

    const leader = response.body.find(candidate => candidate.position === 'leader');
    const vice = response.body.find(candidate => candidate.position === 'viceLeader');

    expect(leader).toBeDefined();
    expect(leader.name).toBe('Candidato de Teste');

    expect(vice).toBeDefined();
    expect(vice.name).toBe('Candidato a Vice');

    expect(query).toBeDefined();
    expect(query.sql).toMatch(/SELECT id, name, position/i);
    expect(response.body[0]).not.toHaveProperty('matric');
    expect(response.body[0]).not.toHaveProperty('phone');
    expect(response.body[0]).not.toHaveProperty('email');
  });

  it('impede aluno de consultar candidatos de outra turma', async () => {
    const response = await request(app)
      .get('/elections/election_test_1/candidates')
      .set(auth(5));

    expect(response.status).toBe(404);
  });

  it('permite ao coordenador cadastrar candidato em eleição do próprio curso', async () => {
    const response = await request(app)
      .post('/elections/election_test_draft/candidates')
      .set(auth(3))
      .send({
        name: 'Novo Candidato',
        matric: 'MAT-002',
        phone: '91988887777',
        email: 'novo@example.com',
        position: 'leader',
      });

    expect(response.status).toBe(201);
    expect(response.body.candidate.name).toBe('Novo Candidato');
    expect(response.body.candidate.electionId).toBe('election_test_draft');
    expect(response.body.candidate.id).toMatch(/^candidate_/);

    const insert = state.queries.find(item =>
      /INSERT INTO election_candidates/i.test(item.sql)
    );

    expect(insert).toBeDefined();
    expect(insert.params[0]).toBe('election_test_draft');
    expect(insert.params[1]).toBe('Engenharia');
    expect(insert.params[4]).toBe('MAT-002');
  });

  it('impede coordenador de cadastrar candidato em outro curso', async () => {
    const response = await request(app)
      .post('/elections/election_test_other_course/candidates')
      .set(auth(3))
      .send({
        name: 'Candidato Externo',
        matric: 'MAT-003',
        position: 'leader',
      });

    expect(response.status).toBe(404);
  });

  it('permite ao reitor cadastrar candidato em eleição em rascunho', async () => {
    const response = await request(app)
      .post('/elections/election_test_draft/candidates')
      .set(auth(4))
      .send({
        name: 'Candidato do Reitor',
        matric: 'MAT-004',
        position: 'viceLeader',
      });

    expect(response.status).toBe(201);
  });

  it('bloqueia cadastro de candidato em eleição aberta', async () => {
    const response = await request(app)
      .post('/elections/election_test_1/candidates')
      .set(auth(3))
      .send({
        name: 'Candidato Tardio',
        matric: 'MAT-005',
        position: 'leader',
      });

    expect(response.status).toBe(404);
  });

  it('rejeita dados obrigatórios inválidos', async () => {
    const response = await request(app)
      .post('/elections/election_test_draft/candidates')
      .set(auth(3))
      .send({
        name: ' ',
        matric: '',
        position: 'cargo-invalido',
      });

    expect(response.status).toBe(400);

    expect(
      state.queries.some(item => /INSERT INTO election_candidates/i.test(item.sql))
    ).toBe(false);
  });

  it('retorna 409 para matrícula duplicada', async () => {
    state.candidateDuplicate = true;

    const response = await request(app)
      .post('/elections/election_test_draft/candidates')
      .set(auth(3))
      .send({
        name: 'Candidato Duplicado',
        matric: 'MAT-001',
        position: 'leader',
      });

    expect(response.status).toBe(409);
  });

  it('bloqueia consulta de candidatos sem autenticação', async () => {
    const response = await request(app)
      .get('/elections/election_test_1/candidates');

    expect(response.status).toBe(401);
  });

  it('bloqueia cadastro de candidatos sem autenticação', async () => {
    const response = await request(app)
      .post('/elections/election_test_draft/candidates')
      .send({
        name: 'Sem Autorização',
        matric: 'MAT-006',
        position: 'leader',
      });

    expect(response.status).toBe(401);
  });
});
describe('API ClassVote - eleições por turma', () => {
  it('lista somente eleições abertas da turma e curso do aluno', async () => {
    const response = await request(app)
      .get('/elections')
      .set(auth(1));

    expect(response.status).toBe(200);

    const query = state.queries.find(item => /FROM elections/i.test(item.sql));

    expect(query).toBeDefined();
    expect(query.sql).toContain("status = 'open'");
    expect(query.params).toEqual(['A', 'Engenharia']);
  });

  it('restringe a consulta do professor ao próprio curso', async () => {
    const response = await request(app)
      .get('/elections')
      .set(auth(2));

    expect(response.status).toBe(200);

    const query = state.queries.find(item => /FROM elections/i.test(item.sql));

    expect(query).toBeDefined();
    expect(query.sql).toContain('course = $1');
    expect(query.params).toEqual(['Engenharia']);
  });

  it('não permite ao aluno consultar eleição de outra turma', async () => {
    const response = await request(app)
      .get('/elections/election_test_1')
      .set(auth(5));

    expect(response.status).toBe(404);
  });

  it('não permite ao coordenador criar eleição em outro curso', async () => {
    const response = await request(app)
      .post('/elections')
      .set(auth(3))
      .send({
        class: 'B',
        course: 'Computação',
        period: '2026.2',
      });

    expect(response.status).toBe(403);

    expect(
      state.queries.some(item => /INSERT INTO elections/i.test(item.sql))
    ).toBe(false);
  });

  it('permite ao reitor criar eleição para turma válida', async () => {
    const response = await request(app)
      .post('/elections')
      .set(auth(4))
      .send({
        class: 'A',
        course: 'Engenharia',
        period: '2026.2',
      });

    expect(response.status).toBe(201);
    expect(response.body.election.status).toBe('draft');
    expect(response.body.election.id).toMatch(/^election_/);

    const insert = state.queries.find(item => /INSERT INTO elections/i.test(item.sql));

    expect(insert).toBeDefined();
    expect(insert.params[1]).toBe('A');
    expect(insert.params[2]).toBe('Engenharia');
    expect(insert.params[3]).toBe('2026.2');
    expect(insert.params[4]).toBe(4);
  });

  it('rejeita criação quando a turma não existe no curso', async () => {
    state.validTurma = false;

    const response = await request(app)
      .post('/elections')
      .set(auth(4))
      .send({
        class: 'Z',
        course: 'Engenharia',
        period: '2026.2',
      });

    expect(response.status).toBe(400);
    expect(
      state.queries.some(item => /INSERT INTO elections/i.test(item.sql))
    ).toBe(false);
  });

  it('retorna 409 quando já existe eleição para turma, curso e período', async () => {
    state.duplicate = true;

    const response = await request(app)
      .post('/elections')
      .set(auth(4))
      .send({
        class: 'A',
        course: 'Engenharia',
        period: '2026.2',
      });

    expect(response.status).toBe(409);
  });

  it('permite ao coordenador iniciar eleição de outra turma do mesmo curso', async () => {
    const response = await request(app)
      .post('/elections/election_test_class_b/start')
      .set(auth(3));

    expect(response.status).toBe(200);
    expect(response.body.election.status).toBe('open');

    expect(
      state.elections.find(row => row.id === 'election_test_class_b').status
    ).toBe('open');

    expect(
      state.elections.find(row => row.id === 'election_test_1').status
    ).toBe('open');
  });

  it('permite ao coordenador encerrar uma eleição aberta do próprio curso', async () => {
    const response = await request(app)
      .post('/elections/election_test_1/end')
      .set(auth(3));

    expect(response.status).toBe(200);
    expect(response.body.election.status).toBe('closed');
    expect(response.body.election.endedAt).toBeTruthy();
  });

  it('não permite ao coordenador iniciar eleição de outro curso', async () => {
    const response = await request(app)
      .post('/elections/election_test_other_course/start')
      .set(auth(3));

    expect(response.status).toBe(404);
    expect(
      state.elections.find(row => row.id === 'election_test_other_course').status
    ).toBe('draft');
  });

  it('não permite reabrir uma eleição encerrada', async () => {
    state.elections.find(row => row.id === 'election_test_1').status = 'closed';

    const response = await request(app)
      .post('/elections/election_test_1/start')
      .set(auth(3));

    expect(response.status).toBe(409);
  });

  it('não permite encerrar uma eleição que ainda não começou', async () => {
    const response = await request(app)
      .post('/elections/election_test_draft/end')
      .set(auth(3));

    expect(response.status).toBe(409);
  });

  it('permite ao reitor iniciar eleição de qualquer curso', async () => {
    const response = await request(app)
      .post('/elections/election_test_other_course/start')
      .set(auth(4));

    expect(response.status).toBe(200);
    expect(response.body.election.status).toBe('open');
  });
  it('bloqueia consulta de eleições sem autenticação', async () => {
    const response = await request(app).get('/elections');
    expect(response.status).toBe(401);
  });
});

describe('API ClassVote - exclusão de usuários e permissões', () => {
  it('permite ao coordenador excluir aluno do próprio curso', async () => {
    const response = await request(app)
      .delete('/users/aluno@teste.com')
      .set(auth(3));

    expect(response.status).toBe(200);
  });

  it('permite ao coordenador excluir professor do próprio curso', async () => {
    const response = await request(app)
      .delete('/users/professor@teste.com')
      .set(auth(3));

    expect(response.status).toBe(200);
  });

  it('impede coordenador de excluir usuário de outro curso', async () => {
    const response = await request(app)
      .delete('/users/aluno2@teste.com')
      .set(auth(3));

    expect(response.status).toBe(404);
  });

  it('impede coordenador de excluir outro coordenador', async () => {
    const response = await request(app)
      .delete('/users/coordenador2@teste.com')
      .set(auth(3));

    expect(response.status).toBe(404);
  });

  it('impede coordenador de excluir o reitor', async () => {
    const response = await request(app)
      .delete('/users/reitor@teste.com')
      .set(auth(3));

    expect(response.status).toBe(404);
  });

  it('permite ao reitor excluir um coordenador', async () => {
    const response = await request(app)
      .delete('/users/coordenador@teste.com')
      .set(auth(4));

    expect(response.status).toBe(200);
  });
});
